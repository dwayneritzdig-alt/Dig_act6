# Student Profile Flutter App

This project contains a simple Student Profile Form with sample information already filled in.

Sample information:
- Full Name: Dwayne Ritz Dig
- Age: 20
- Gender: Male
- Address: Sorsogon
- Contact Number: 09519557041
- Email: dwayne@gmail.com

Features:
- Required-field validation
- Submit button
- Displays student information
- Clear/Reset button

Run:
flutter pub get
flutter run
