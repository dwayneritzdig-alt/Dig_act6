import 'package:flutter/material.dart';

void main() {
  runApp(const StudentProfileApp());
}

class StudentProfileApp extends StatelessWidget {
  const StudentProfileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Student Profile',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const StudentProfilePage(),
    );
  }
}

class StudentProfilePage extends StatefulWidget {
  const StudentProfilePage({super.key});

  @override
  State<StudentProfilePage> createState() => _StudentProfilePageState();
}

class _StudentProfilePageState extends State<StudentProfilePage> {
  final _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController(text: 'Dwayne Ritz Dig');
  final ageController = TextEditingController(text: '20');
  final addressController = TextEditingController(text: 'Sorsogon');
  final contactController = TextEditingController(text: '09519557041');
  final emailController = TextEditingController(text: 'dwayne@gmail.com');

  String? gender = 'Male';
  bool submitted = false;

  void submitForm() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        submitted = true;
      });
    }
  }

  void clearForm() {
    nameController.clear();
    ageController.clear();
    addressController.clear();
    contactController.clear();
    emailController.clear();

    setState(() {
      gender = null;
      submitted = false;
    });
  }

  @override
  void dispose() {
    nameController.dispose();
    ageController.dispose();
    addressController.dispose();
    contactController.dispose();
    emailController.dispose();
    super.dispose();
  }

  Widget textField({
    required String label,
    required TextEditingController controller,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (value) {
          if (value == null || value.trim().isEmpty) {
            return '$label is required';
          }
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Profile Form')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              textField(
                label: 'Full Name',
                controller: nameController,
              ),
              textField(
                label: 'Age',
                controller: ageController,
                keyboardType: TextInputType.number,
              ),
              DropdownButtonFormField<String>(
                value: gender,
                decoration: const InputDecoration(
                  labelText: 'Gender',
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(value: 'Male', child: Text('Male')),
                  DropdownMenuItem(value: 'Female', child: Text('Female')),
                  DropdownMenuItem(value: 'Other', child: Text('Other')),
                ],
                onChanged: (value) {
                  setState(() {
                    gender = value;
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Gender is required';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              textField(
                label: 'Address',
                controller: addressController,
              ),
              textField(
                label: 'Contact Number',
                controller: contactController,
                keyboardType: TextInputType.phone,
              ),
              textField(
                label: 'Email',
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: submitForm,
                      child: const Text('SUBMIT'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: clearForm,
                      child: const Text('CLEAR'),
                    ),
                  ),
                ],
              ),
              if (submitted) ...[
                const SizedBox(height: 20),
                const Divider(),
                const Text(
                  'Student Information',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text('Full Name: ${nameController.text}'),
                Text('Age: ${ageController.text}'),
                Text('Gender: $gender'),
                Text('Address: ${addressController.text}'),
                Text('Contact Number: ${contactController.text}'),
                Text('Email: ${emailController.text}'),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
